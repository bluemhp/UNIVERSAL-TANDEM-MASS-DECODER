/**
 * 
 */
/**
 * @author dell
 *
 */
module tandem {
	requires java.desktop;
}